/* 
 * File:   main.h
 * Author: adity
 *
 * Created on 29 November, 2024, 1:21 PM
 */

#ifndef MAIN_H
#define	MAIN_H
int threshold(void);
int node(void);
void mode();
static void init_config(void);

#define TRUE 1;
#define FALSE 0;

#endif	/* MAIN_H */

