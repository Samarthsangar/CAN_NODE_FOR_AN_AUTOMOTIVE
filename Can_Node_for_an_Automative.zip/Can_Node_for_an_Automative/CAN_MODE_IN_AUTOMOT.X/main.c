/******************************************CAN NODE FOR AN AUTOMOTIVE (CLIENT SIDE)***********************************************************/
/*
 * Project Name : CAN NODE FOR AN AUTOMOTIVE.
 * Date : 02/12/24
 * Description : This part contains the client side for and automotive system.
 *               client side having the information like engine temp, speed of 
 *               car, fuel level etc. This can be communicate with the server side
 *               & provide the information to the server. This is helpful for keeping 
 *               vehicle proper maintenance.
*/



#include <xc.h>                 //including of header file's
#include"adc.h"
#include"clcd.h"
#include"can.h"
#include"matrix_keypad.h"
#include"main.h"

unsigned short default_screen_flag=1,ON_flag=0;     //Flag to check conditions
unsigned int temp_adc=0,thershold=50,speed_adc;     //variables to store event's
unsigned char fuel[4]={'0','1','0','\0'};           //character array to store fuel level
unsigned char key;                                  //variable to check switch pressed event
unsigned char node_id[8]={'0','0','0','1'};         //character array to store node_id 
unsigned char * display[]={"THSHOLD ","FLUE THRESHOLD","NODE ID:"}; //array of character pointer for display event's


int Long_press(short SWITCH)           //function to check switch level triggring status
{
    for(unsigned int i=0;i<45000; i++)      //running loop
    {
        key=read_switches(LEVEL_CHANGE);    //continuous checking switch status
        if(key==SWITCH && i==41000)         //if switch is level triggred for 2 sec then return true(1)
        {
            return 1;
        }
        else if(key!=SWITCH)                //else return false(0)
            return 0;
    }
}


static void init_config(void)           //function for initial configuration of peripherals of MC
{
    init_can();         //can bus initial_con function call
    init_clcd();        //clcd initial_con function call
    init_matrix_keypad();   //Matrix keypad initial_con function call
    init_adc();         //adc initial_con function call
}
void can_print(int chcek)               //function for transmit and receiving the data from the can bus
{
        //this is validation of node ID which is received from can bus
    if((chcek==1)||(ON_flag==1 && can_payload[D0]==node_id[0] && can_payload[D1]==node_id[1] && can_payload[D2]==node_id[2] && can_payload[D3]==node_id[3]))         
    {
            node_id[4]=fuel[0];            // assigning three bytes to node id about fuel
            node_id[5]=fuel[1];
            node_id[6]=fuel[2];
            node_id[7]='\0';
            can_transmit(node_id);        // first transmit 8 byte data node id + fuel
            char data[8];                 // creating one char array for storing 8 byte data
            data[0]=(temp_adc/10)+'0';
            data[1]=(temp_adc%10)+'0';
            if(ON_flag)
            {
                data[2]='O';
                data[3]='N';
            }
            else
            {
                data[2]='O';
                data[3]='F';
            }
            data[4]=(speed_adc/10)+'0';
            data[5]=(speed_adc%10)+'0';
            data[6]='\0';
            data[7]='\0';
            for(unsigned long int delay=50000;delay--;);            // after transmit first 8 byte giving same delay for next Transmission. 
            can_transmit(data);                                 // This is a Second transmission 
            node_id[4]='\0';                                  // After that we are resizing the node ID 
    }
    
          //This is the validation for checking if the engine is on or off Through the node id Receive from another node
    else if((ON_flag==0 && can_payload[D0]==node_id[0] && can_payload[D1]==node_id[1] && can_payload[D2]==node_id[2] && can_payload[D3]==node_id[3]))
    {
        char data[8]={0};
        data[0]='E';
        can_transmit(data);           // Here we are transporting only one indication. 
    }
    
}
int node()                                        // Function for changing the node ID And displaying
{
   CLEAR_DISP_SCREEN;
   unsigned short temp=((node_id[0]-'0')*1000)+((node_id[1]-'0')*100) + ((node_id[2]-'0')*10) + node_id[3]-'0';        //Storing the previous value for safer side. 
   while(1)
   {
       if(can_receive())        // If can receive function is called       
       {
           can_print(0);
       }
       key=read_switches(STATE_CHANGE);            //Reading the switch value
       clcd_print("NODE ID:",LINE1(0));
       clcd_print(node_id,LINE2(0));
       if(key==MK_SW1)
       {
            if(Long_press(MK_SW1))              // Long press function is called here
            {
                can_print(1);                  //Here we are transmitting the data to server. 
                CLEAR_DISP_SCREEN;
                return 1;
            }
           if(((node_id[3])+=1)==58)                 // This is for incrementing the node ID. 
           {
               node_id[3]=48;
               if(((node_id[2])+=1)==58)
               {
                   node_id[2]=48;
                   node_id[3]=48;
                   if(((node_id[1])+=1)==58)
                   {
                      node_id[3]=48;
                      node_id[2]=48; 
                      node_id[1]=48;
                        if(((node_id[0])+=1)==58)
                        {
                           node_id[3]=48;
                           node_id[2]=48; 
                           node_id[1]=48;
                           node_id[0]=48;

                        }
                   }
               }
           }
       }
       else if(key==MK_SW2)
       {
           if(Long_press(MK_SW2))
            { 
                CLEAR_DISP_SCREEN;
                node_id[0]=(temp/1000)+'0';                  //  Here we are not saving our node ID. We are saving previous value
                node_id[1]=((temp/100)%10)+'0';
                node_id[2]=((temp/10)%10)+'0';
                node_id[3]=(temp%10)+'0';
                node_id[4]='\0';
                return 0;
            }   
           if(((node_id[3])-=1)==47)                //This is for decrementing the node id. 
           {
               node_id[3]=57;
               if(((node_id[2])-=1)==47)
               {
                   node_id[3]=57;
                   node_id[2]=57;
                   if(((node_id[1])-=1)==47)
                   {
                      node_id[3]=57;
                      node_id[2]=57; 
                      node_id[1]=57;
                        if(((node_id[0])-=1)==47)
                        {
                           node_id[0]=57;
                           node_id[1]=57; 
                           node_id[2]=57;
                           node_id[3]=57;
                        }
                   }
               }
           }
       }
   }
}
void fuel_fun()                // this is a fuel function to display
{
    CLEAR_DISP_SCREEN;
    unsigned short thre_chcek=((((fuel[0]-'0')*100))+((fuel[1]-'0')*10)+((fuel[2]-'0')));      //Here we are converting fuel character into one integer
    while(1)
    {
        if(can_receive())          // If in between my can function is called It will go there 
        {
            can_print(0);
        }
        key=read_switches(STATE_CHANGE);
        if(key==MK_SW1)
            return;
        clcd_print("FUEL LEVEL:",LINE1(0));
        clcd_print("THERSHOLD ",LINE2(0));
        clcd_print(fuel,LINE2(10));
        clcd_putch('%',LINE2(13));
        if(thershold<=thre_chcek)              // Here we are checking fuel integer with a threshold level which is set above
        {
            clcd_putch('<',LINE2(8));         //If the fuel level is greater than threshold level, it will show greater than 
        }
        else
        {
            clcd_putch('>',LINE2(8));        // Or else less than. 
        }
    }
}
void temp()                             // This function is for displaying temperature
{
    CLEAR_DISP_SCREEN;
    while(1)
    {
        if(can_receive())                 // If in between can receive function is called?
        {
            can_print(0);
        }
        key=read_switches(STATE_CHANGE);
        if(key==MK_SW1)
            return;
        clcd_print("ENGINE TEMP:",LINE1(0));
        clcd_print("THERSHOLD ",LINE2(0));
        clcd_putch((temp_adc/10+'0'),LINE2(10));
        clcd_putch((temp_adc%10+'0'),LINE2(11));
        clcd_putch(0xDF,LINE2(12));
        clcd_putch('C',LINE2(13));
        if(thershold<=temp_adc)            //If the temperature level is greater than threshold level, it will show greater than 
        {
            clcd_putch('<',LINE2(8));  
        }
        else
        {
            clcd_putch('>',LINE2(8));     // Or else less than.
        }
    }
}
int threshold(void)                  // this is threshold function for display 
{
    CLEAR_DISP_SCREEN;
    clcd_putch(0x7E,LINE1(0));
    clcd_print(" TEMPERATURE",LINE1(1));             //display the temperature 
    clcd_print("  FUEL",LINE2(0));                  // display the fuel
    short thre_flag=1;
    while(1)
    {
        if(can_receive())
        {
            can_print(0);
        }
        key=read_switches(STATE_CHANGE);
        if(key==MK_SW1)                              // sw1 to return back
        {
            CLEAR_DISP_SCREEN;
            return 0;
        }
        else if(key==MK_SW2)
        {
            if(Long_press(MK_SW2))               // long press it will go to menu
            {
                if(thre_flag)
                {
                    temp();
                    CLEAR_DISP_SCREEN;
                    clcd_print("  FUEL",LINE2(0));
                }
                else
                {
                   fuel_fun();
                   CLEAR_DISP_SCREEN;
                   clcd_print("  TEMPERATURE",LINE1(0));
                }
            }
            else if(thre_flag)    
                thre_flag=0;
            else
                thre_flag=1;
        }
        if(thre_flag)
        {
            clcd_putch(0x7E,LINE1(0));
            clcd_print(" TEMPERATURE",LINE1(1));
            clcd_putch(' ',LINE2(0));
        }
        else
        {
           clcd_putch(0x7E,LINE2(0));
           clcd_print(" FUEL",LINE2(1));
           clcd_putch(' ',LINE1(0)); 
        }
    }
}

void mode()                                       //mode function 
{
    CLEAR_DISP_SCREEN;
    short mode_flag=1;
    clcd_putch(0x7E,LINE1(0));
    clcd_print(" SET NODE ID",LINE1(1));
    clcd_print("  SET THRESHOLD",LINE2(0));
    while(1)
    {     
        if(can_receive())                        // in between if can call is called
        {
            can_print(0);
        }
        key=read_switches(STATE_CHANGE);
        if(key==MK_SW1)                        //switch to return back to main 
        {
            return;
        }
        else if(key==MK_SW2)
        {
            if(Long_press(MK_SW2))
            {
                if(mode_flag)
                {
                    if(node())
                    {
                        return;
                    }
                    CLEAR_DISP_SCREEN;
                    clcd_print("  SET THRESHOLD",LINE2(0));
                }
                else
                {
                    if(threshold())
                    {
                        return;
                    }
                    CLEAR_DISP_SCREEN;
                    clcd_print("  SET NODE ID",LINE1(0));
                }
            }
            else if(mode_flag)    
                mode_flag=0;
            else
                mode_flag=1;
        }
        if(mode_flag)
        {
            clcd_putch(0x7E,LINE1(0));
            clcd_print(" SET NODE ID",LINE1(1));
            clcd_putch(' ',LINE2(0));
        }
        else
        {
           clcd_putch(0x7E,LINE2(0)); 
           clcd_print(" SET THRESHOLD",LINE2(1));
           clcd_putch(' ',LINE1(0)); 
        }
        
    }   
}
int main()
{
    init_config();                 // Here we called initial configuration. 
    while(1)
    {
        if(can_receive())         // Whenever can receive function is called? 
        {
            can_print(0);
        }
        key=read_switches(STATE_CHANGE);        // read the switch keys
        if(default_screen_flag)                 // Initial flag
        {
            clcd_print(" ET   FL  SB SPD",LINE1(0));
            if(ON_flag)                        // Displaying if my car is in on state. 
            {
                temp_adc=read_adc(CHANNEL6)/10;    //  Reading the value from the temperature sensor. Temperature sensor is analog It will convert into digital. 
                if(temp_adc>=100)
                    temp_adc=99;
                speed_adc=read_adc(CHANNEL4)/10;   // Reading the value from the potential meter of analog and converted into digital.
                if(speed_adc>=100)                 // If my speed is above 100. 
                    speed_adc=99;
                clcd_putch((temp_adc/10+'0'),LINE2(0));
                clcd_putch((temp_adc%10+'0'),LINE2(1));
                clcd_putch(0xDF,LINE2(2));
                clcd_putch('C',LINE2(3));
                clcd_print(fuel,LINE2(5));
                clcd_putch('%',LINE2(8));
                clcd_print("ON",LINE2(10));
                clcd_putch((speed_adc/100+'0'),LINE2(13));
                clcd_putch(((speed_adc/10)%10+'0'),LINE2(14));
                clcd_putch((speed_adc%10+'0'),LINE2(15));
            }
            else
            {
                clcd_print("---- ---- ",LINE2(0));
                clcd_print("OF ",LINE2(10));
                clcd_print("---",LINE2(13));
            }   
        }
        if(key==MK_SW2)            // Changing the flag value by the key Deduction. 
        {
           if(ON_flag)
               ON_flag=0;
           else
               ON_flag=1;
        } 
        else if(key==MK_SW1 && ON_flag==1)   // if only my car is in on state
        {
            mode();                         // mode function called
            CLEAR_DISP_SCREEN;
        }
            
    }
}