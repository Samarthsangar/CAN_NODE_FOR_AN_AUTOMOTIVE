#include <xc.h>
#include "isr.h"
#include "main.h"

extern unsigned char ch;

void __interrupt() isr(void)
{
   unsigned int i=0;
   if (RCIF == 1)
    {
       if(OERR==1)
           OERR=0;
       
       ch = RCREG;
       RCIF = 0;
    }
}




