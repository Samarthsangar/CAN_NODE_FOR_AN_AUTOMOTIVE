/******************************************CAN NODE FOR AN AUTOMOTIVE (CLIENT SIDE)***********************************************************/
/*
 * Project Name : CAN NODE FOR AN AUTOMOTIVE.
 * Date : 02/12/24
 * Description : This part contains the client side for and automotive system.
 *               client side having the information like engine temp, speed of 
 *               car, fuel level etc. This can be communicate with the server side
 *               & provide the information to the server. This is helpful for keeping 
 *               vehicle proper maintenance.
*/

/*SERVER & HOST CODE*/


#include <xc.h>
#include "uart.h"
#include "can.h"
#include "main.h"


unsigned char ch='\0';
unsigned int node_id;
unsigned short flag=0,change_flag=0,status_off=0;
unsigned char print[13];



static void init_config(void)
{
    init_uart();
    init_can();
    PEIE= 1;
	ADCON1 = 0x0F;
    GIE = 1; 
}


void main(void) 
{
    init_config();
    unsigned int first_can_receive=1,print_flag=0,i=0;
    
    while(1)
    {
        
        if(can_receive())               //check data received or not
        {
            flag=0;                     //if received change flag's
            change_flag=0;
            if(can_payload[D0]=='E')       // if it will receive the 'E' status is off
            {
                status_off=1;
            }
            else if(first_can_receive)      // can receive is working two times because at a time it will receive and transmit 8 bit data
            {
                first_can_receive=0;
                while(i<7)
                {
                    print[i]=(can_payload[D0+i]);                   // first reading 8bit of data
                    i++;
                }
            }
            else
            {
                first_can_receive=1;
                print_flag=1;
                int x=0;
                while(i<13)
                {
                    print[i]=(can_payload[D0+x]);           // reading next 8 bit of data 
                    i++;
                    x++;
                }
                print[i]='\0';
                i=0;
            }
            
        }
        if(print_flag)                             // printing on tera team
        {
            print_flag=0;
            puts("\n\n\r");
            puts("Node_ID is: ");
            while(print_flag<4)
            {
                putch(print[print_flag++]);
            }
            puts("\n\r");
            puts("Fuel: ");
            while(print_flag<7)
            {
                putch(print[print_flag++]);
            }
            putch('%');
            puts("\n\r");
            puts("Engine Temperature: ");
            while(print_flag<9)
            {
                putch(print[print_flag++]);
            }
            puts(" 'c");
            puts("\n\r");
            puts("Engine Status: ");
            while(print_flag<11)
            {
                putch(print[print_flag++]);                    // printing the which we have store
            }
            puts("\n\r");
            puts("Speed: ");
            while(print_flag<13)
            {
                putch(print[print_flag++]);
            }
            puts("Km/h");
            print_flag=0;
            puts("\n\r");
        }
        else if(status_off)
        {
            status_off=0;
            puts("\n\r-->Engine off Status");
            puts("\n\r");
        }
        
        if(flag==1)                                    //check flag & print message on Tara term
        {
            puts("\n\rEnter the NODE_ID [Max 4 byte] : ");
            flag=4;
        }
        if(ch!='\0' && (ch!='\r' && ch!='\n'))        //take one one byte data from tara term
        {
            putch(ch);
            
            if(change_flag==1)
            {
                if((ch>='0'&& ch<='9'))             //only number data add
                {
                    node_id=((node_id*10)+(ch-48));
                    if(node_id>=10000)            //if more then four byte then remove 1 
                    {
                       node_id/=10;
                    }
                }
            }
            ch='\0';
        }

        else if(ch!='\0' && (ch=='\r' || ch=='\n'))
        {
            change_flag++;
            flag++;
            if(change_flag>=2)                      //check flag & transmit the data
            {
                can_transmit();                   // transmit the data to can bus
                puts("\n\r");
                change_flag=0;                 // reset the value again
                flag=0;
                node_id=0;
            }
            ch='\0';
        }
    }
    return;
}

